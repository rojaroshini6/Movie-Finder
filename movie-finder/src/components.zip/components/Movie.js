import React from 'react';

const Movie = (props) => {
  return (
    <div className='card'>
      <div className='card-image'>
        <img src='images/sample-1.jpg' />
        <span className='card-title'>{props.title}</span>
      </div>
    </div>
  );
};

export default Movie;

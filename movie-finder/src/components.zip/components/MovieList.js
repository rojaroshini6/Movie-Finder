import React from 'react';
import Movie from './Movie';

const MovieList = (props) => {
  console.log(props);
  return (
    <div className='container'>
      <div className='row'>
        <div className='col s12 m6'>
          {props.movie.map((movie1, i) => {
            return <Movie key={i} title={movie1.title} />;
          })}
        </div>
      </div>
    </div>
  );
};

export default MovieList;

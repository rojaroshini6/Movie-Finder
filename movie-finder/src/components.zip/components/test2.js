import React, { useState } from 'react';
import Nav from './components/Nav';
import SearchArea from './components/SearchArea';
import MovieList from './components/MovieList';

const App = (props) => {
  const [movies, setMovies] = useState([]);
  const [searchTerm, setSearchterm] = useState('');

  const apiKey = '4f5890e24c242acfabd0a04dc0e2582b';

  const handleSubmit = (e) => {
    console.log(searchTerm);
    e.preventDefault();
    fetch(
      `https://api.themoviedb.org/3/search/movie?api_key=${apiKey}&query=${searchTerm}`
    )
      .then((data) => data.json())
      .then((data) => {
        console.log(data);
        setMovies((movies) => [...data]);
        console.log(movies);
      });
  };

  const handleChange = (e) => {
    setSearchterm(e.target.value);
  };

  return (
    <div className='App'>
      <Nav />
      <SearchArea handleSubmit={handleSubmit} handleChange={handleChange} />
      <MovieList movie={movies} />
    </div>
  );
};

export default App;
